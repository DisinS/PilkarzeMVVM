﻿using PilkarzeMVVM.Model;
using PilkarzeMVVM.ViewModel.Base;
using System;
using System.Collections.Generic;
using System.Text;

using System.Collections.ObjectModel;
using System.Windows.Input;

namespace PilkarzeMVVM.ViewModel
{
    using Base;
    using Model;
    using System.Windows;

    internal class CommandCenter : ViewModelBase
    {
        private Team team = new Team();
        public ObservableCollection<Player> Players { get => new ObservableCollection<Player>(team.GetPlayers); }
        #region Current Properties
        public string CurrentName { get; set; } = "";
        public string CurrentLastName { get; set; } = "";
        public int CurrentAge { get; set; } = 30;
        public int CurrentWeight { get; set; } = 75;
        public int CurrentIndex { get; set; } = -1;
        #endregion

        private ICommand _addPlayer = null;
        public ICommand AddPlayer
        {
            get
            {
                if (_addPlayer == null)
                {
                    _addPlayer = new RelayCommand(arg =>
                    {
                        team.AddPlayer(CurrentName, CurrentLastName, CurrentAge, CurrentWeight);
                        onPropertyChanged(nameof(Players));
                    },
                    arg => !string.IsNullOrEmpty(CurrentName) && !string.IsNullOrEmpty(CurrentLastName)
                    );
                }
                return _addPlayer;
            }
        }
        private ICommand _editPlayer = null;
        public ICommand EditPlayer
        {
            get
            {
                if(_editPlayer == null)
                {
                    _editPlayer = new RelayCommand(arg =>
                    {
                        Player player = new Player(CurrentName, CurrentLastName, CurrentAge, CurrentWeight);
                        if (!Team.Exist(player))
                        {
                            MessageBoxResult decision = MessageBox.Show("Czy na pewno chcesz zmienić dane?", "Edycja", MessageBoxButton.YesNo);
                            if (decision == MessageBoxResult.Yes)
                            {
                                team.EditPlayer(CurrentIndex, CurrentName, CurrentLastName, CurrentAge, CurrentWeight);
                                onPropertyChanged(nameof(Players));
                            }
                        }
                        else
                            MessageBox.Show("Taki gracz już istnieje!", "Edycja");
                    },
                    arg => CurrentIndex != -1 && !string.IsNullOrEmpty(CurrentName) && !string.IsNullOrEmpty(CurrentLastName)
                    );
                }
                return _editPlayer;
            }
        }
        private ICommand _removePlayer = null;
        public ICommand RemovePlayer
        {
            get
            {
                if(_removePlayer == null)
                {
                    _removePlayer = new RelayCommand(arg =>
                    {
                        MessageBoxResult decision = MessageBox.Show("Czy na pewno chcesz usunąć?", "Usuń", MessageBoxButton.YesNo);
                        if (decision == MessageBoxResult.Yes)
                        {
                            team.RemovePlayer(CurrentIndex);
                            onPropertyChanged(nameof(Players));
                        }
                    },
                    arg => CurrentIndex != -1
                    );
                }
                return _removePlayer;
            }
        }
        private ICommand _loadPlayer = null;
        public ICommand LoadPlayer
        {
            get
            {
                if(_loadPlayer == null)
                {
                    _loadPlayer = new RelayCommand(arg =>
                    {
                        Player chosen = Players[CurrentIndex];
                        CurrentName = chosen.Name;
                        CurrentLastName = chosen.Lastname;
                        CurrentAge = chosen.Age;
                        CurrentWeight = chosen.Weight;
                        onPropertyChanged(nameof(CurrentName), nameof(CurrentLastName), nameof(CurrentAge), nameof(CurrentWeight));
                    },
                    arg => CurrentIndex != -1
                    );
                }

                return _loadPlayer;
            }
        }

        private ICommand _saveTeam = null;
        public ICommand SaveTeam
        {
            get
            {
                if (_saveTeam == null)
                {
                    _saveTeam = new RelayCommand(arg =>
                    team.SaveTeam(@"ListOfPlayers.json"),
                    arg => true);
                }
                return _saveTeam;
            }
        }


    }
}
