﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PilkarzeMVVM.Model
{
    class Player
    {
        public string Name { get; set; }
        public string Lastname { get; set; }
        public int Age { get; set; }
        public int Weight { get; set; }
        public Player(string name, string lastName, int age, int weight)
        {
            Name = name;
            Lastname = lastName;
            Age = age;
            Weight = weight;
        }
        public override string ToString() => $"{Name} {Lastname}, wiek: {Age}, waga: {Weight}kg";
        public Player() { }

    }
}
