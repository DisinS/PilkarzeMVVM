﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace PilkarzeMVVM.Model
{
    class Team
    {
        static List<Player> team = new List<Player>();
        public List<Player> GetPlayers { get => team; }
        public Team()
        {
            team = Team.LoadTeam(@"ListOfPlayers.json");
        }
        public void AddPlayer(string name, string lastName, int age, int weight)
        {
            Player player = new Player(name, lastName, age, weight);
            
            if(!Exist(player))
                team.Add(player);
        }
        public void EditPlayer(int index, string name, string lastName, int age, int weight)
        {
            Player player = new Player(name, lastName, age, weight);
            if (!Exist(player))
            {
                team[index].Name = name;
                team[index].Lastname = lastName;
                team[index].Age = age;
                team[index].Weight = weight;
            }
        }
        public void RemovePlayer(int index)
        {
            team.RemoveAt(index);
        }
        public void SaveTeam(string fileName)
        {
            string json = JsonConvert.SerializeObject(team);
            File.WriteAllText(fileName, json);
        }
        public static bool Exist(Player player)
        {
            for (int i = 0; i < team.Count; i++)
                if (team[i].Name.Equals(player.Name) && team[i].Lastname.Equals(player.Lastname) &&
                    team[i].Age.Equals(player.Age) && team[i].Weight.Equals(player.Weight))
                    return true;
            return false;
        }
        public static List<Player> LoadTeam(string fileName)
        {
            List<Player> players = new List<Player>();
            if (File.Exists(fileName))
            {
                using (StreamReader file = File.OpenText(fileName))
                {
                    string json = file.ReadToEnd();
                    players = JsonConvert.DeserializeObject<List<Player>>(json);
                }
            }
            return players;
        }

    }
}
